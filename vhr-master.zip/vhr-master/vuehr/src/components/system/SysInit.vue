<template>
  <div>
    <h1>
      初始化数据库
    </h1>
  </div>
</template>
