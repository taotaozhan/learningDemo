<template>
  <div>
    <h1>奖惩规则</h1>
  </div>
</template>
