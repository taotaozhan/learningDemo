<template>
  <div>
    <h1>员工培训</h1>
  </div>
</template>
